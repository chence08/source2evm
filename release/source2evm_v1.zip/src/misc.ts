export const zeroPad = (num, length) => (num).toString(16).toUpperCase().padStart(length, '0');
